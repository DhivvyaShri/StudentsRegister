package student;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;


public class stud_reg{

    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        try {
            // 1. Load JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 2. Establish Connection
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/college",
                    "root",
                    "root"   // change to your DB password
            );

            // 3. Disable Auto-Commit
            con.setAutoCommit(false);

            // 4. Get Input from User
            System.out.print("Enter Student Name: ");
            String name = sc.nextLine();

            System.out.print("Enter Roll Number: ");
            int roll = sc.nextInt();
            sc.nextLine(); // consume newline

            System.out.print("Enter Department: ");
            String dept = sc.nextLine();

            // 5. Prepare SQL Query
            String sql = "INSERT INTO students(name, roll, dept) VALUES (?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, name);
            ps.setInt(2, roll);
            ps.setString(3, dept);

            // 6. Execute Query
            int rows = ps.executeUpdate();

            // 7. Commit Transaction
            con.commit();

            if (rows > 0) {
                System.out.println("✅ Student Registered Successfully!");
            }

            // 8. Close Resources
            ps.close();
            con.close();
            sc.close();

        } catch (Exception e) {
            System.out.println("❌ Error: " + e.getMessage());
        }
    }
}
